(function () {
    "use strict";

    let lastAutoUrl = "";
    let pendingTimer = null;

    function discover() {
        const instances = [];
        const routers = [];
        const nodes = document.querySelectorAll("div, body, html");
        nodes.forEach((node) => {
            const app = node.__vue_app__;
            const vm = node.__vue__;
            const instance = app || vm;
            if (!instance) return;
            const router = app && app.config && app.config.globalProperties
                ? app.config.globalProperties.$router
                : vm && (vm.$router || (vm.$root && vm.$root.$router));
            if (instance && !instances.includes(instance)) instances.push(instance);
            if (router && !routers.includes(router)) routers.push(router);
        });
        return {instances: instances, routers: routers};
    }

    function vueVersion(instances) {
        for (const instance of instances) {
            try {
                if (instance.version) return instance.version;
                if (instance.$options && instance.$options._base && instance.$options._base.version) return instance.$options._base.version;
            } catch (e) {}
        }
        return "unknown";
    }

    function routerBase(router) {
        try {
            return (router.options && router.options.base) || (router.history && router.history.base) || "";
        } catch (e) {
            return "";
        }
    }

    function joinPath(parent, child) {
        if (!child) return parent || "/";
        if (child.startsWith("/")) return child;
        return (parent || "").replace(/\/$/, "") + "/" + child;
    }

    function routeUrl(router, fullPath) {
        const base = routerBase(router) || "/";
        const origin = window.location.origin;
        try {
            if (router && typeof router.resolve === "function") {
                const resolved = router.resolve({path: fullPath || "/"});
                if (resolved && resolved.href) return new URL(resolved.href, window.location.href).href;
            }
        } catch (e) {}
        try {
            const isHash = router && (router.mode === "hash" || (router.history && /HashHistory/i.test(router.history.constructor && router.history.constructor.name)));
            if (isHash) return origin + base.replace(/#?$/, "#") + (fullPath.startsWith("/") ? fullPath : "/" + fullPath);
            return new URL((base.replace(/\/$/, "") + "/" + String(fullPath || "/").replace(/^\//, "")) || "/", window.location.origin + window.location.pathname).href;
        } catch (e) {
            return fullPath || "/";
        }
    }

    function safeMeta(meta) {
        if (!meta || typeof meta !== "object") return {};
        try {
            return JSON.parse(JSON.stringify(meta));
        } catch (e) {
            return {};
        }
    }

    function flattenRoutes(routes, router, parent) {
        const result = [];
        (routes || []).forEach((route) => {
            const fullPath = joinPath(parent, route.path || "");
            const aliases = route.alias ? (Array.isArray(route.alias) ? route.alias : [route.alias]) : [];
            result.push({
                path: route.path || "",
                fullPath: fullPath || "/",
                fullUrl: routeUrl(router, fullPath || "/"),
                name: route.name || "",
                aliases: aliases,
                meta: safeMeta(route.meta || {})
            });
            if (Array.isArray(route.children)) result.push.apply(result, flattenRoutes(route.children, router, fullPath));
        });
        return result;
    }

    function rawRoutes(router) {
        try {
            if (typeof router.getRoutes === "function") return router.getRoutes();
            if (router.options && Array.isArray(router.options.routes)) return router.options.routes;
        } catch (e) {}
        return [];
    }

    function allRoutes(routers) {
        const routes = [];
        const seen = new Set();
        routers.forEach((router) => {
            flattenRoutes(rawRoutes(router), router, "").forEach((route) => {
                const key = route.fullUrl || route.fullPath + "|" + route.name;
                if (!seen.has(key)) {
                    seen.add(key);
                    routes.push(route);
                }
            });
        });
        return routes;
    }

    function waitFor(value, timeout) {
        if (!value || typeof value.then !== "function") return Promise.resolve();
        return Promise.race([
            value.catch(function () {}),
            new Promise((resolve) => setTimeout(resolve, timeout))
        ]);
    }

    async function loadRouteComponents(routers, instances) {
        let loaded = 0;
        let skipped = 0;
        const visited = new Set();
        const vm = instances[0] && (instances[0].proxy || instances[0]);
        const components = [];
        function collect(routes) {
            (routes || []).forEach((route) => {
                if (typeof route.component === "function" && !visited.has(route.component)) {
                    visited.add(route.component);
                    components.push(route.component);
                }
                if (route.components && typeof route.components === "object") Object.keys(route.components).forEach((key) => {
                    const component = route.components[key];
                    if (typeof component === "function" && !visited.has(component)) {
                        visited.add(component);
                        components.push(component);
                    }
                });
                if (Array.isArray(route.children)) collect(route.children);
            });
        }
        routers.forEach((router) => collect(rawRoutes(router)));
        for (let i = 0; i < components.length; i += 8) {
            await Promise.all(components.slice(i, i + 8).map(async (component) => {
                try {
                    await waitFor(component.call(vm), 5000);
                    loaded++;
                } catch (e) {
                    skipped++;
                }
            }));
        }
        return {loadedCount: loaded, skippedCount: skipped};
    }

    function resourceUrls() {
        return Array.from(new Set(performance.getEntriesByType("resource")
            .map((entry) => entry.name)
            .filter((url) => /^https?:/i.test(url) && /\.(?:m?js|jsx?|tsx?)(?:[?#].*)?$/i.test(url))));
    }

    async function analyze(manual) {
        const found = discover();
        let routes = allRoutes(found.routers);
        let loadResult = {loadedCount: 0, skippedCount: 0};
        if (manual && found.routers.length) {
            loadResult = await loadRouteComponents(found.routers, found.instances);
            await new Promise((resolve) => setTimeout(resolve, 200));
            routes = allRoutes(discover().routers);
        }
        const result = {
            foundVue: found.instances.length > 0,
            foundRouter: found.routers.length > 0,
            vueVersion: vueVersion(found.instances),
            routes: routes,
            loadedCount: loadResult.loadedCount,
            skippedCount: loadResult.skippedCount,
            resources: resourceUrls()
        };
        window.postMessage({type: "FS_VUE_RESULT", current: window.location.href, result: result}, "*");
        return result;
    }

    function scheduleAutoDetect() {
        clearTimeout(pendingTimer);
        pendingTimer = setTimeout(() => {
            const url = window.location.href;
            const found = discover();
            if (!found.instances.length || url === lastAutoUrl) return;
            lastAutoUrl = url;
            analyze(false).catch(function () {});
        }, 500);
    }

    window.addEventListener("message", (event) => {
        if (event.source !== window || !event.data || event.data.type !== "FS_VUE_REQUEST") return;
        analyze(event.data.manual !== false).catch(function () {});
    });

    new MutationObserver(scheduleAutoDetect).observe(document.documentElement, {childList: true, subtree: true});
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scheduleAutoDetect, {once: true});
    else scheduleAutoDetect();
    window.addEventListener("load", scheduleAutoDetect, {once: true});
})();
