
function setTextContentById(id){
    document.getElementById(id).textContent = chrome.i18n.getMessage(id);
}

function init_locales() {
    const settingIdList = [
        "Zhuye",
        "Peizhi",
		"settingClearCache",
		"settingClearLocalStorage",
		"settingGlobalFloatingWindow",
		"settingAutoTimeout",
		"settingWebhook",
		"settingWebhookUrl",
		"settingWebhookMethod",
		"settingWebhookArg",
		"settingWebhookHeaders",
		"settingDomainAllowList",
		"settingSafe"
    ];

    for (const id of settingIdList) {
    	try{
    		setTextContentById(id)
    	}catch{
    		console.log(id)
    	}
        
    }

    const settingResetAndSaveList = document.getElementsByClassName("settingResetAndSave");
    for (const settingResetAndSave of settingResetAndSaveList) {
    	settingResetAndSave.textContent = chrome.i18n.getMessage("settingResetAndSave");
    }
    const settingSaveList = document.getElementsByClassName("settingSave");
    for (const settingSave of settingSaveList) {
    	settingSave.textContent = chrome.i18n.getMessage("settingSave");
    }
    document.getElementById("allowlist").placeholder = chrome.i18n.getMessage("settingDomainAllowListTip");
}

init_locales()

document.getElementById("save").onclick=function () {
	let webhook_setting = {};
	webhook_setting['url'] = document.getElementById('url').value;
	webhook_setting['method'] = document.getElementById('method').value;
	webhook_setting['arg'] = document.getElementById('arg').value;
	try {
		webhook_setting['headers'] = JSON.parse(document.getElementById('headers').value || "{}");
	} catch (error) {
		alert("自定义 headers 必须是合法 JSON");
		return;
	}
	// console.log(webhook_setting);
	chrome.storage.local.set({"webhook_setting": webhook_setting});
}
document.getElementById("reset").onclick=function () {
	let webhook_setting = {"url":"","arg":"","headers":{}};
	document.getElementById('url').value = "";
	document.getElementById('arg').value = "";
	document.getElementById('headers').value = "{}";
	// console.log(webhook_setting);
	chrome.storage.local.set({"webhook_setting": webhook_setting});
}

document.getElementById("save_allowlist").onclick=function () {
	snsArr = document.getElementById('allowlist').value.split(/[(\r\n)\r\n]+/);
	snsArr.forEach((item, index)=>{
		if(!item){
			snsArr.splice(index,1);
		}
	})
	// console.log(snsArr)
	chrome.storage.local.set({"allowlist": snsArr});
}
document.getElementById("reset_allowlist").onclick=function () {
	document.getElementById('allowlist').value = "";
	chrome.storage.local.set({"allowlist": []});
}

document.getElementById("settingClearLocalStorage").onclick=function () {
	chrome.storage.local.clear();
	console.log(chrome.i18n.getMessage("settingClearComplete"));
	alert(chrome.i18n.getMessage("settingClearComplete"));
}

document.getElementById("global_float").onclick=function () {
	// var webhook_setting = {};
	chrome.storage.local.get(["global_float"], function(settings){
		// console.log(settings);
		chrome.storage.local.set({"global_float": settings["global_float"]==true ? false : true});
		document.getElementById('global_float').textContent = settings["global_float"]==true ? chrome.i18n.getMessage("settingClosed") : chrome.i18n.getMessage("settingOpened");
	});
	// console.log(webhook_setting);
}

document.getElementById("fetch_timeout").onclick=function () {
	// var webhook_setting = {};
	chrome.storage.local.get(["fetch_timeout"], function(settings){
		// console.log(settings);
		chrome.storage.local.set({"fetch_timeout": settings["fetch_timeout"]==true ? false : true});
		document.getElementById('fetch_timeout').textContent = settings["fetch_timeout"]==true ? chrome.i18n.getMessage("settingClosed") : chrome.i18n.getMessage("settingOpened");
	});
	// console.log(webhook_setting);
}

document.getElementById("settingSafeMode").onclick=function () {
	// var webhook_setting = {};
	chrome.storage.local.get(["settingSafeMode"], function(settings){
		// console.log(settings);
		chrome.storage.local.set({"settingSafeMode": settings["settingSafeMode"]==true ? false : true});
		document.getElementById('settingSafeMode').textContent = settings["settingSafeMode"]==true ? chrome.i18n.getMessage("settingClosed") : chrome.i18n.getMessage("settingOpened");
	});
}


chrome.storage.local.get(["webhook_setting"], function(settings){
	// console.log(settings);
	if(!settings || settings == {} || !settings["webhook_setting"] ){
        console.log('获取webhook_setting失败');
        return;
    }
	document.getElementById('url').value = settings["webhook_setting"]['url'];
	document.getElementById('method').value = settings["webhook_setting"]['method'];
	document.getElementById('arg').value = settings["webhook_setting"]['arg'];
	document.getElementById('headers').value = JSON.stringify(settings["webhook_setting"]['headers']);
});
chrome.storage.local.get(["global_float"], function(settings){
	document.getElementById('global_float').textContent = settings["global_float"]==true ? chrome.i18n.getMessage("settingOpened") : chrome.i18n.getMessage("settingClosed");
});
chrome.storage.local.get(["fetch_timeout"], function(settings){
	document.getElementById('fetch_timeout').textContent = settings["fetch_timeout"]==true ? chrome.i18n.getMessage("settingOpened") : chrome.i18n.getMessage("settingClosed");
});

chrome.storage.local.get(["settingSafeMode"], function(settings){
	document.getElementById('settingSafeMode').textContent = settings["settingSafeMode"]==true ? chrome.i18n.getMessage("settingOpened") : chrome.i18n.getMessage("settingClosed");
	if(settings["settingSafeMode"]==null){
		chrome.storage.local.set({"settingSafeMode": true});
		document.getElementById('settingSafeMode').textContent = chrome.i18n.getMessage("settingOpened");
	}
});
chrome.storage.local.get(["allowlist"], function(allowlist){
	if(allowlist && allowlist["allowlist"]){
		document.getElementById('allowlist').textContent = allowlist["allowlist"].join('\n');
	}
});

const defaultAI = {
	AIbaseURL: "https://api.openai.com/v1",
	AIapiKey: "",
	AImodel: "gpt-4o-mini",
	AISystemPrompt: "你是 JavaScript 动态加载分析器。输入是一段可能生成 webpack/Vite/RequireJS chunk 路径的代码，以及一个已加载 JS 文件 URL。请枚举代码中可推导的全部 JavaScript 文件名，并根据输入 URL 推断同目录或相对目录的完整 HTTP(S) URL。只输出 URL 或 .js 文件名，每行一个；最后一行必须是 ok 或 error。无法确定或不是动态 JS 路径生成函数时只输出 error。不要输出解释、Markdown 或其他内容。",
	AIUserPrompt: "请还原这段动态加载代码。已加载代码来源：{{source}}。如果代码中存在对象映射、hash、chunk 编号或 webpack publicPath，请枚举所有可能的 .js 结果，并补全为完整 URL。\n\n{{code}}"
};

function fillAI(settings) {
	const config = Object.assign({}, defaultAI, settings || {});
	Object.keys(defaultAI).forEach(function(key) {
		document.getElementById(key).value = config[key] || "";
	});
}

chrome.storage.sync.get(["AI"], function(settings) {
	fillAI(settings && settings.AI);
});

document.getElementById("save_AI").onclick = function() {
	const AI = {};
	Object.keys(defaultAI).forEach(function(key) {
		AI[key] = document.getElementById(key).value.trim();
	});
	chrome.storage.sync.set({AI: AI}, function() {
		alert("AI 配置已保存");
	});
};

document.getElementById("reset_AI").onclick = function() {
	fillAI(defaultAI);
	chrome.storage.sync.set({AI: defaultAI}, function() {
		alert("AI 配置已恢复默认");
	});
};
