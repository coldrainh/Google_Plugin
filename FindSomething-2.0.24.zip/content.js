// @Date    : 2020-09-12 16:26:48
// @Author  : residuallaugh
(function(){
    var protocol = window.location.protocol;
    var host = window.location.host;
    var domain_host = host.split(':')[0];
    var href = window.location.href;
    // var source = document.getElementsByTagName('html')[0].innerHTML;
    var source = document.documentElement.outerHTML;
    var settingSafeMode = true;
    init_source(source);

    // 获取页面中所有的 iframe 元素，执行同样的逻辑
    var iframes = document.querySelectorAll('iframe');
    iframes.forEach(function(iframe) {
        iframe.addEventListener('load', function() {
            var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
            source = iframeDocument.documentElement.outerHTML
            // console.log(iframeDocument.documentElement.outerHTML);
            init_source(source);
        });
    });

    function init_source(source) {
        var hostPath;
        var urlPath;
        var urlWhiteList = ['.google.com','.amazon.com','portswigger.net'];
        var target_list = [];
        // console.log(source)
        var source_href = source.match(/href=['"].*?['"]/g);
        var source_src = source.match(/src=['"].*?['"]/g);
        var script_src = source.match(/<script\b[^><]*?\bsrc=['"].*?['"]/gi);
        chrome.storage.local.get(["settingSafeMode"], function(settings){
            settingSafeMode = settings["settingSafeMode"]==false ? false : true;
        });
        chrome.storage.local.get(["allowlist"], function(settings){
            // console.log(settings , settings['allowlist'])
            if(settings && settings['allowlist']){
                urlWhiteList = settings['allowlist'];
            }
            for(var i = 0;i < urlWhiteList.length;i++){
                if(host.endsWith(urlWhiteList[i]) || domain_host.endsWith(urlWhiteList[i])){
                    console.log('域名在白名单中，跳过当前页')
                    return ;
                }
            }
            // target_list.push(window.location.href);
            
            // console.log(source_href,source_src,script_src)
            if(source_href){
                for(var i=0;i<source_href.length;i++){
                    var u = deal_url(source_href[i].substring(6,source_href[i].length-1));
                    if(u){
                        target_list.push(u);
                    }
                }
            }
            if(source_src){
                for(var i=0;i<source_src.length;i++){
                    var u = deal_url(source_src[i].substring(5,source_src[i].length-1));
                    if(u){
                        target_list.push(u);
                    }
                }
            }
            
            const uniqueTargets = Array.from(new Set(target_list)).filter(function(url) {
                return url && url !== href;
            });
            chrome.runtime.sendMessage({greeting: "find",data: uniqueTargets, current: href, source: source});
        });
    
        function is_script(u){
            if(script_src){
                for(var i=0;i<script_src.length;i++){
                    if (script_src[i].indexOf(u)>0){
                        return true
                    }
                }
            }
            return false
        }
        function isJavaScriptFile(url) {
            try {
                // 使用URL构造函数解析URL
                const parsedUrl = new URL(url);

                // 获取URL的pathname部分
                const pathname = parsedUrl.pathname;

                // 检查pathname是否以.js结尾
                return pathname.endsWith('.js');
            } catch (error) {
                // 如果URL无效，则捕获错误
                return false;
            }
        }

        function deal_url(u){
            let url;
            if(u.substring(0,4)=="http"){
                url = u;
            }
            else if(u.substring(0,2)=="//"){
                url = protocol+u;
            }
            else if(u.substring(0,1)=='/'){
                url = protocol+'//'+host+u;
            }
            else if(u.substring(0,2)=='./'){
                if (href.indexOf('#')>0) {
                    tmp_href = href.substring(0,href.indexOf('#'))
                }else{
                    tmp_href = href;
                }
                url = tmp_href.substring(0,tmp_href.lastIndexOf('/')+1)+u;
            }else{
                // console.log("not match prefix:"+u+",like http // / ./")
                if (href.indexOf('#')>0) {
                    tmp_href = href.substring(0,href.indexOf('#'))
                }else{
                    tmp_href = href;
                }
                url = tmp_href.substring(0,tmp_href.lastIndexOf('/')+1)+u;
            }
            // console.log(settingSafeMode)
            if(settingSafeMode && !isJavaScriptFile(url) && !is_script(u)){
                // console.log('非js:'+u);
                // if(u.indexOf('.js')>-1){
                //     console.log('有js关键字:'+u);
                // }
                return ;
            }
            // console.log(url)
            return url;
        }
    }

})()

window.addEventListener('message', function(event) {
    if (event.source !== window || !event.data) return;
    if (event.data.type === 'FS_VUE_RESULT') {
        chrome.runtime.sendMessage({
            greeting: 'vueRoutes',
            current: event.data.current,
            version: event.data.result && event.data.result.vueVersion,
            foundVue: event.data.result && event.data.result.foundVue,
            foundRouter: event.data.result && event.data.result.foundRouter,
            loadedCount: event.data.result && event.data.result.loadedCount,
            skippedCount: event.data.result && event.data.result.skippedCount,
            routes: event.data.result && event.data.result.routes,
            resources: event.data.result && event.data.result.resources
        });
    }
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.greeting === 'vueAnalyze') {
        window.postMessage({
            type: 'FS_VUE_REQUEST',
            manual: request.manual !== false
        }, '*');
        sendResponse({success: true});
        return true;
    }
    if (request.greeting === 'toast') {
        var toast = document.getElementById('findsomething-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'findsomething-toast';
            toast.style.cssText = 'position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:360px;padding:10px 14px;background:#111;color:#fff;border-radius:4px;font:14px sans-serif;box-shadow:0 2px 10px rgba(0,0,0,.25);';
            document.documentElement.appendChild(toast);
        }
        toast.textContent = request.message || '';
        clearTimeout(window.__findsomethingToastTimer);
        window.__findsomethingToastTimer = setTimeout(function() {
            if (toast && toast.parentNode) toast.parentNode.removeChild(toast);
        }, 3500);
        sendResponse({success: true});
        return true;
    }
});


chrome.storage.local.get(["global_float"], function(settings){
    // console.log(settings);
    if (settings["global_float"]!=true){
        return
    }
    // console.log(settings["global_float"]);
    // console.log("findsomething-divglobal_float");
    // 使用自定义标签
    const body = document.getElementsByTagName('html')[0];
    const div = document.createElement('div');
    div.setAttribute("id","findsomething-float-div");
    div.innerHTML = `
    <findsomething-div id="findsomething_neko" style="width:450px;max-height:500px;font-size:14px;color:#000000;box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1) ;background-color: #fff;border-radius: 5px;border: 1px solid #ebebeb;left:20px;top:20px;position: fixed;z-index: 1000000;overflow:scroll;">
          <findsomething-div id="findsomething_neko-title" style="display: flex;justify-content: space-between;">
            <findsomething-div id="findsomething_taskstatus" style="height: 34px; line-height: 34px; margin-left: 10px;"></findsomething-div>
            <findsomething-div style="cursor: pointer;margin-top: 2px;margin-right: 10px;" onclick='(function(){document.getElementById("findsomething-float-div").removeChild(document.getElementById("neko"));})()'>隐藏</findsomething-div>
          </findsomething-div>
            <findsomething-div class="findsomething-featured">
                <findsomething-div class="findsomething-title">敏感信息<button type="button" class="finsomething_copy" name="secret">复制</button></findsomething-div>
                <findsomething-p id="findsomething_secret" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title findsomething-hot-title">热加载敏感信息<button type="button" class="finsomething_copy" name="hot_secret">复制</button></findsomething-div>
                <findsomething-p id="findsomething_hot_secret" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
            </findsomething-div>
            <findsomething-div style="width: 300px; margin-top: 10px;">
                <findsomething-div class="findsomething-title">IP<button type="button" class="finsomething_copy" name="ip">复制</button></findsomething-div>
                <findsomething-p id="findsomething_ip" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">IP_PORT<button class="findsomething_copy" name="ip_port">复制</button></findsomething-div>
                <findsomething-p id="findsomething_ip_port" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">域名<button class="findsomething_copy" name="domain">复制</button></findsomething-div>
                <findsomething-p id="findsomething_domain" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">身份证<button class="findsomething_copy" name="sfz">复制</button></findsomething-div>
                <findsomething-p id="findsomething_sfz" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">手机号<button class="findsomething_copy" name="mobile">复制</button></findsomething-div>
                <findsomething-p id="findsomething_mobile" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">邮箱<button class="findsomething_copy" name="mail">复制</button></findsomething-div>
                <findsomething-p id="findsomething_mail" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">JWT<button class="findsomething_copy" name="jwt">复制</button></findsomething-div>
                <findsomething-p id="findsomething_jwt" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">算法<button class="findsomething_copy" name="algorithm">复制</button></findsomething-div>
                <findsomething-p id="findsomething_algorithm" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">Path<button class="findsomething_copy" name="path">复制</button></findsomething-div>
                <findsomething-p id="findsomething_path" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">IncompletePath<button class="findsomething_copy" name="incomplete_path">复制</button></findsomething-div>
                <findsomething-p id="findsomething_incomplete_path" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">Url<button class="findsomething_copy" name="url">复制</button></findsomething-div>
                <findsomething-p id="findsomething_url" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
                <findsomething-div class="findsomething-title">StaticUrl<button class="findsomething_copy" name="static">复制</button></findsomething-div>
                <findsomething-p id="findsomething_static" style="word-break:break-word;margin-left:10px;">🈚️</findsomething-p>
            </findsomething-div>
    </findsomething-div>
        <style type="text/css">
        .findsomething_copy {
            border-style: none;
            background-color: #ffffff;
            float: right;
            margin-right: 0px;
            font-size: 14px;
        }
        .findsomething-featured {
            width: 410px;
            margin: 8px 10px 14px;
            padding: 8px;
            border: 1px solid #d9e7f7;
            border-radius: 4px;
            background-color: #fbfdff;
        }
        .findsomething-featured findsomething-p {
            max-height: 180px;
            overflow: auto;
        }
        .findsomething-hot-title {
            border-color: #d99500;
        }
        .findsomething-result-item {
            display: flex;
            align-items: flex-start;
            gap: 5px;
            margin: 3px 0;
        }
        .findsomething-result-value {
            flex: 1;
            min-width: 0;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .findsomething-result-actions {
            display: flex;
            flex-shrink: 0;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 5px;
        }
        .findsomething-result-action {
            border: 0;
            padding: 0;
            background: transparent;
            color: #2878d8;
            font-size: 12px;
            cursor: pointer;
            white-space: nowrap;
        }
        .findsomething-result-source {
            color: #ea6000;
            text-decoration: none;
        }
        findsomething-div{
            display: block;
        }
        findsomething-p {
            display: block;
            margin-top: 14px;
            margin-bottom: 14px;
            line-height: 14px;
        }

        .findsomething-title {
            font-size: 16px;
            font-weight: bold;
            border-left: 4px solid black;
            text-indent: 4px;
            height: 16px;
            line-height: 16px;
            width: 100%;
            margin-left: 10px;
        }

        button{
            cursor: pointer
        }
        </style>
        `
    body.appendChild(div)
    var neko = document.querySelector('#findsomething_neko');
    var nekoW = neko.offsetWidth;
    var nekoH = neko.offsetHeight;
    var cuntW = 0;
    var cuntH = 0;
    neko.style.left = parseInt(document.body.offsetWidth - nekoW)+1 + 'px';
    neko.style.top = '50px';
    move(neko, 0, 0);
    function move(obj, w, h) {
        if (obj.direction === 'left') {
            obj.style.left = 0 - w + 'px';
        } else if (obj.direction === 'right') {

            obj.style.left = document.body.offsetWidth - nekoW + w + 'px';
        }
        if (obj.direction === 'top') {
            obj.style.top = 0 - h + 'px';
        } else if (obj.direction === 'bottom') {
            obj.style.top = document.body.offsetHeight - nekoH + h + 'px';
        }
    }

    function rate(obj, a) {
        //  console.log(a);
        obj.style.transform = ' rotate(' + a + ')'
    }

    var nekotitle = document.querySelector('#findsomething_neko-title');
    nekotitle.onmousedown = function (e) {
        var nekoL = e.clientX - neko.offsetLeft;
        var nekoT = e.clientY - neko.offsetTop;
        document.onmousemove = function (e) {
            cuntW = 0;
            cuntH = 0;
            neko.direction = '';
            neko.style.transition = '';
            neko.style.left = (e.clientX - nekoL) + 'px';
            neko.style.top = (e.clientY - nekoT) + 'px';
            if (e.clientX - nekoL < 5) {
                neko.direction = 'left';
            }
            if (e.clientY - nekoT < 5) {
                neko.direction = 'top';
            }
            if (e.clientX - nekoL > document.body.offsetWidth - nekoW - 5) {
                neko.direction = 'right';
            }
            if (e.clientY - nekoT > document.body.offsetHeight - nekoH - 5) {
                neko.direction = 'bottom';
            }

            move(neko, 0, 0);


        }
    }
    neko.onmouseover = function () {
        move(this, 0, 0);
        rate(this, 0)
    }

    neko.onmouseout = function () {
        // move(this, nekoW / 2, nekoH / 2);
        move(this, nekoW / 2, 0);
        // move(this, 0, 0);
    }

    neko.onmouseup = function () {
        document.onmousemove = null;
        this.style.transition = '.5s';
        // move(this, nekoW / 2, nekoH / 2);
        move(this, nekoW / 2, 0);
    }

    window.onresize = function () {
        var bodyH = document.body.offsetHeight;
        var nekoT = neko.offsetTop;
        var bodyW = document.body.offsetWidth;
        var nekoL = neko.offsetLeft;

        if (nekoT + nekoH > bodyH) {
            neko.style.top = bodyH - nekoH + 'px';
            cuntH++;
        }
        if (bodyH > nekoT && cuntH > 0) {
            neko.style.top = bodyH - nekoH + 'px';
        }
        if (nekoL + nekoW > bodyW) {
            neko.style.left = bodyW - nekoW + 'px';
            cuntW++;
        }
        if (bodyW > nekoL && cuntW > 0) {
            neko.style.left = bodyW - nekoW + 'px';
        }

        // move(neko, nekoW / 2, nekoH / 2);
        move(this, nekoW / 2, 0);
        // move(this, 0, 0);
    }
});

function init_copy() {
    var elements = document.getElementsByClassName("findsomething_copy");
    if (elements) {
        for (var i=0, len=elements.length|0; i<len; i=i+1|0) {
            let ele_name = elements[i].name;
            elements[i].onclick=function () {
                // console.log('copy begin');
                var inp =document.createElement('textarea');
                document.body.appendChild(inp)
                inp.value =document.getElementById(ele_name).textContent;
                inp.select();
                document.execCommand('copy',false);
                inp.remove();
                // console.log('copy end');
            }
        }
    }
};
setTimeout(()=>{
    init_copy();
}, 500);

function sleep (time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

var key = ["secret","hot_secret","ip","ip_port","domain","path","incomplete_path","url","static","sfz","mobile","mail","jwt","algorithm"]

function safe_info_source(value) {
    return /^(?:https?|file):/i.test(value || "") ? value : "";
}

function info_source_list(value) {
    var values = Array.isArray(value) ? value : [value];
    var result = [];
    values.forEach(function(item) {
        var source = safe_info_source(item);
        if (source && result.indexOf(source) === -1) result.push(source);
    });
    return result;
}

function copy_info_value(value) {
    var inp = document.createElement('textarea');
    document.body.appendChild(inp);
    inp.value = value;
    inp.select();
    document.execCommand('copy', false);
    inp.remove();
}

function show_info(result_data) {
    if (!result_data) return;
    for (var k in key) {
        var resultKey = key[k];
        var container = document.getElementById("findsomething_" + resultKey);
        if (!container) continue;
        var values = Array.isArray(result_data[resultKey]) ? result_data[resultKey] : [];
        container.textContent = "";
        if (!values.length) {
            container.textContent = "🈚️";
            continue;
        }
        var sourceMap = resultKey === "hot_secret" ? (result_data.hot_source || {}) : (result_data.source || {});
        values.forEach(function(value) {
            var row = document.createElement("findsomething-div");
            row.className = "findsomething-result-item";
            var valueNode = document.createElement("span");
            valueNode.className = "findsomething-result-value";
            valueNode.textContent = value;
            var actions = document.createElement("span");
            actions.className = "findsomething-result-actions";
            var copyButton = document.createElement("button");
            copyButton.className = "findsomething-result-action";
            copyButton.textContent = "复制";
            copyButton.title = "复制此条信息";
            copyButton.onclick = function() {
                copy_info_value(String(value));
                copyButton.textContent = "已复制";
                setTimeout(function() { copyButton.textContent = "复制"; }, 900);
            };
            var sourceUrls = info_source_list(sourceMap[value]);
            if (sourceUrls.length) {
                sourceUrls.forEach(function(sourceUrl, index) {
                    var sourceLink = document.createElement("a");
                    sourceLink.className = "findsomething-result-action findsomething-result-source";
                    var label = /\.m?js(?:[?#]|$)/i.test(sourceUrl) ? "打开JS" : "打开来源";
                    sourceLink.textContent = sourceUrls.length > 1 ? label + " " + (index + 1) : label;
                    sourceLink.title = sourceUrl;
                    sourceLink.href = sourceUrl;
                    sourceLink.target = "_blank";
                    sourceLink.rel = "noopener noreferrer";
                    actions.appendChild(sourceLink);
                });
            } else {
                var noSource = document.createElement("span");
                noSource.className = "findsomething-result-action";
                noSource.textContent = "无来源";
                actions.appendChild(noSource);
            }
            actions.insertBefore(copyButton, actions.firstChild);
            row.append(valueNode, actions);
            container.appendChild(row);
        });
    }
}
function get_info() {
    chrome.runtime.sendMessage({greeting: "get", current: window.location.href}, function(result_data) {
        let taskstatus = document.getElementById('findsomething_taskstatus');
        if(!taskstatus){
            return;
        }
        if(!result_data|| result_data['done']!='done'){
            // console.log('还未提取完成');
            if(result_data){
                show_info(result_data);

                taskstatus.textContent = "处理中.."+result_data['donetasklist'].length+"/"+result_data['tasklist'].length;
            }else{
                taskstatus.textContent = "处理中..";
            }
            sleep(100);
            get_info();
            return;
        }
        taskstatus.textContent = "处理完成："+result_data['donetasklist'].length+"/"+result_data['tasklist'].length;
        show_info(result_data);
        // 结果不一致继续刷新
        if(result_data['donetasklist'].length!=result_data['tasklist'].length){
            get_info();
        }
        return;
    });
}
get_info();
