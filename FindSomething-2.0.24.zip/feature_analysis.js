(function () {
    "use strict";

    const MAX_DYNAMIC_ITEMS = 300;
    const MAX_CODE_LENGTH = 16000;
    const MAX_TRACE_VARIABLES = 80;
    const JS_EXTENSIONS = /\.(?:m?js|jsx?|tsx?)(?:[?#].*)?$/i;
    const DYNAMIC_MARKERS = /(?:\.src\s*=|setAttribute\s*\(\s*["']src|createElement\s*\(\s*["']script|import\s*\(|require\s*\(|webpack|__webpack|\.p\b|chunk)/i;

    function featureState(current) {
        const item = search_data[current];
        if (!item) return null;
        if (!Array.isArray(item.showCode)) item.showCode = [];
        if (!item.ai || typeof item.ai !== "object") item.ai = {};
        if (!Array.isArray(item.visited_urls)) item.visited_urls = [];
        if (!item.source || typeof item.source !== "object") item.source = {};
        if (!Array.isArray(item.hot_secret)) item.hot_secret = [];
        if (!item.hot_source || typeof item.hot_source !== "object") item.hot_source = {};
        if (!item.dynamicResources || typeof item.dynamicResources !== "object") item.dynamicResources = {};
        if (!item.trace || typeof item.trace !== "object") item.trace = {};
        return item;
    }

    function isJavaScriptSource(url, source) {
        if (JS_EXTENSIONS.test(url || "")) return true;
        if (typeof source !== "string") return false;
        return /<script\b/i.test(source) || DYNAMIC_MARKERS.test(source);
    }

    function extractScriptUnits(source) {
        if (typeof source !== "string" || !source.trim()) return [];
        if (!/<(?:html|head|body|script|div)\b/i.test(source)) return [source];
        const units = [];
        let match;
        const scriptPattern = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
        while ((match = scriptPattern.exec(source)) !== null) {
            const code = match[1].replace(/<!--[\s\S]*?-->/g, "").trim();
            if (code) units.push(code);
        }
        const attributePattern = /\bon\w+\s*=\s*(["'])([\s\S]*?)\1/gi;
        while ((match = attributePattern.exec(source)) !== null) {
            if (match[2].trim()) units.push(match[2].trim());
        }
        const javascriptUrlPattern = /\bhref\s*=\s*(["'])javascript:([\s\S]*?)\1/gi;
        while ((match = javascriptUrlPattern.exec(source)) !== null) {
            if (match[2].trim()) units.push(match[2].trim());
        }
        return units.length ? units : [source];
    }

    function findMatching(text, start, opening, closing) {
        let depth = 0;
        let quote = "";
        let escaped = false;
        let lineComment = false;
        let blockComment = false;
        for (let i = start; i < text.length; i++) {
            const ch = text[i];
            const next = text[i + 1];
            if (lineComment) {
                if (ch === "\n") lineComment = false;
                continue;
            }
            if (blockComment) {
                if (ch === "*" && next === "/") {
                    blockComment = false;
                    i++;
                }
                continue;
            }
            if (quote) {
                if (escaped) {
                    escaped = false;
                } else if (ch === "\\") {
                    escaped = true;
                } else if (ch === quote) {
                    quote = "";
                }
                continue;
            }
            if (ch === "/" && next === "/") {
                lineComment = true;
                i++;
                continue;
            }
            if (ch === "/" && next === "*") {
                blockComment = true;
                i++;
                continue;
            }
            if (ch === "\"" || ch === "'" || ch === "`") {
                quote = ch;
                continue;
            }
            if (ch === opening) depth++;
            if (ch === closing && --depth === 0) return i;
        }
        return -1;
    }

    function extractFunctions(code) {
        const functions = [];
        const patterns = [
            /\bfunction\s*[A-Za-z0-9_$]*\s*\([^)]*\)\s*\{/g,
            /(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>\s*\{/g
        ];
        patterns.forEach((pattern) => {
            let match;
            while ((match = pattern.exec(code)) !== null) {
                const open = code.indexOf("{", match.index + match[0].length - 1);
                const close = findMatching(code, open, "{", "}");
                if (open < 0 || close < 0) continue;
                const value = code.slice(match.index, close + 1).trim();
                if (value.length <= MAX_CODE_LENGTH && DYNAMIC_MARKERS.test(value)) functions.push({start: match.index, end: close + 1, code: value});
            }
        });
        return functions;
    }

    function statementAround(code, index) {
        let start = index;
        let end = index;
        while (start > 0 && !/[;{}\n]/.test(code[start - 1])) start--;
        while (end < code.length && !/[;{}\n]/.test(code[end])) end++;
        return code.slice(start, end + (code[end] === ";" ? 1 : 0)).trim();
    }

    function dynamicCandidates(source) {
        const candidates = [];
        const seen = new Set();
        extractScriptUnits(source).forEach((unit) => {
            const functions = extractFunctions(unit);
            functions.forEach((item) => {
                if (!seen.has(item.code)) {
                    seen.add(item.code);
                    candidates.push(item.code);
                }
            });
            const marker = /(?:\.src\s*=|setAttribute\s*\(\s*["']src|createElement\s*\(\s*["']script|import\s*\(|require\s*\(|__webpack_require__\.[\w$]+\s*=)/gi;
            let match;
            while ((match = marker.exec(unit)) !== null) {
                const insideFunction = functions.some((item) => match.index >= item.start && match.index <= item.end);
                if (insideFunction) continue;
                const value = statementAround(unit, match.index);
                if (value && DYNAMIC_MARKERS.test(value) && !seen.has(value)) {
                    seen.add(value);
                    candidates.push(value);
                }
            }
        });
        return candidates.slice(0, MAX_DYNAMIC_ITEMS);
    }

    function splitTopLevel(expression, separator) {
        const parts = [];
        let start = 0;
        let depth = 0;
        let quote = "";
        let escaped = false;
        for (let i = 0; i < expression.length; i++) {
            const ch = expression[i];
            if (quote) {
                if (escaped) escaped = false;
                else if (ch === "\\") escaped = true;
                else if (ch === quote) quote = "";
                continue;
            }
            if (ch === "\"" || ch === "'" || ch === "`") {
                quote = ch;
                continue;
            }
            if ("([{".includes(ch)) depth++;
            else if (")]}`".includes(ch)) depth--;
            else if (ch === separator && depth === 0) {
                parts.push(expression.slice(start, i).trim());
                start = i + 1;
            }
        }
        parts.push(expression.slice(start).trim());
        return parts.filter(Boolean);
    }

    function decodeLiteral(value) {
        const text = value.trim();
        if (text.length < 2) return null;
        const quote = text[0];
        if (!["\"", "'", "`"].includes(quote) || text[text.length - 1] !== quote) return null;
        if (quote === "`") {
            if (/\$\{/.test(text)) return null;
            return text.slice(1, -1);
        }
        try {
            return JSON.parse(quote === "'" ? '"' + text.slice(1, -1).replace(/\\'/g, "'").replace(/"/g, '\\"') + '"' : text);
        } catch (e) {
            return text.slice(1, -1).replace(/\\([\\"'])/g, "$1");
        }
    }

    function parseObjectValues(expression) {
        const values = [];
        const body = expression.replace(/^\s*\{/, "").replace(/\}\s*(?:\[[^\]]*\])?\s*$/, "");
        const pattern = /(?:["']([^"']+)["']|([A-Za-z0-9_$-]+))\s*:\s*(["'`])([\s\S]*?)\3/g;
        let match;
        while ((match = pattern.exec(body)) !== null) values.push(match[4]);
        return values;
    }

    function buildEnvironment(code) {
        const env = Object.create(null);
        const literalPattern = /\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;\n]+)/g;
        let match;
        while ((match = literalPattern.exec(code)) !== null) {
            const literal = decodeLiteral(match[2].trim());
            if (literal !== null) env[match[1]] = [literal];
            else if (/^\s*\{/.test(match[2])) {
                const values = parseObjectValues(match[2]);
                if (values.length) env[match[1]] = values;
            }
        }
        return env;
    }

    function resolveExpression(expression, env) {
        const parts = splitTopLevel(expression.replace(/^[({\s]+|[)}\s;]+$/g, ""), "+");
        if (!parts.length) return [];
        let values = [""];
        let known = false;
        parts.forEach((part) => {
            let next = [];
            const literal = decodeLiteral(part);
            if (literal !== null) next = [literal];
            else if (env[part]) next = env[part];
            else if (/^\{/.test(part)) next = parseObjectValues(part);
            else {
                const objectMatch = part.match(/^(.*)\[[^\]]*\]$/);
                if (objectMatch && /^\s*\{/.test(objectMatch[1])) next = parseObjectValues(objectMatch[1]);
                else if (objectMatch && env[objectMatch[1].trim()]) next = env[objectMatch[1].trim()];
            }
            if (next.length) {
                known = true;
                const combined = [];
                values.forEach((left) => next.forEach((right) => {
                    if (combined.length < 100) combined.push(left + right);
                }));
                values = combined;
            }
        });
        return known ? values.filter((value) => value.length > 3) : [];
    }

    function normalizeResource(value, sourceUrl) {
        let text = String(value || "").trim().replace(/^[-*`\s]+|[`\s,;:)]+$/g, "");
        if (!text || !/\.m?js(?:[?#].*)?$/i.test(text)) return null;
        try {
            const url = new URL(text, sourceUrl || undefined);
            if (!/^https?:$/i.test(url.protocol)) return null;
            return url.href;
        } catch (e) {
            return null;
        }
    }

    function resourceCandidates(code, sourceUrl) {
        const env = buildEnvironment(code);
        const values = [];
        const add = (value) => {
            const url = normalizeResource(value, sourceUrl);
            if (url && !values.includes(url)) values.push(url);
        };
        const literalPattern = /["'`]([^"'`\r\n]{1,500}\.m?js(?:[?#][^"'`\r\n]*)?)["'`]/gi;
        let match;
        while ((match = literalPattern.exec(code)) !== null) add(match[1]);
        const expressionPatterns = [
            /\.src\s*=\s*([^;\n]+)/gi,
            /setAttribute\s*\(\s*["']src["']\s*,\s*([^)]*)\)/gi,
            /(?:import|require)\s*\(\s*([^)]*)\)/gi,
            /\breturn\s+([^;\n]+(?:\.js|\.m?js)[^;\n]*)/gi
        ];
        expressionPatterns.forEach((pattern) => {
            while ((match = pattern.exec(code)) !== null) {
                resolveExpression(match[1], env).forEach(add);
            }
        });
        return values;
    }

    function recordDynamicCode(current, sourceUrl, source) {
        const item = featureState(current);
        if (!item || !isJavaScriptSource(sourceUrl, source)) return [];
        const candidates = dynamicCandidates(source);
        let changed = false;
        candidates.forEach((code) => {
            if (!item.showCode.includes(code)) {
                item.showCode.push(code);
                item.source[code] = sourceUrl;
                item.dynamicResources[code] = resourceCandidates(code, sourceUrl);
                changed = true;
            }
        });
        if (changed) chrome.storage.local.set({["findsomething_result_" + current]: item});
        return candidates;
    }

    function extractParameters(code) {
        const functionMatch = code.match(/\bfunction\s*[A-Za-z0-9_$]*\s*\(([^)]*)\)/);
        if (functionMatch) return functionMatch[1].split(",").map((value) => value.trim().replace(/=.*/, "")).filter(Boolean);
        const arrowMatch = code.match(/^(?:\(([^)]*)\)|([A-Za-z_$][\w$]*))\s*=>/);
        if (!arrowMatch) return [];
        return (arrowMatch[1] || arrowMatch[2]).split(",").map((value) => value.trim()).filter(Boolean);
    }

    function traceFunctionParameters(code, source) {
        const completeSource = (typeof source === "string" && source.length > code.length && source.includes(code)) ? source : code;
        const env = buildEnvironment(completeSource);
        const localEnv = Object.assign(Object.create(null), env, buildEnvironment(code));
        const variables = [];
        const names = new Set(extractParameters(code));
        const assignmentPattern = /\b(?:var|let|const)\s+([A-Za-z_$][\w$]*)\s*=\s*([^;\n]+)/g;
        let match;
        while ((match = assignmentPattern.exec(code)) !== null) names.add(match[1]);
        names.forEach((name) => {
            const values = localEnv[name] || [];
            variables.push({name: name, value: values.length === 1 ? values[0] : (values.length ? values : null), source: "static"});
        });
        return {success: true, variables: variables.slice(0, MAX_TRACE_VARIABLES)};
    }

    function sendMessageSafe(api, method, args) {
        try {
            const result = chrome[api][method].apply(chrome[api], args);
            if (result && typeof result.catch === "function") result.catch(function () {});
        } catch (e) {}
    }

    function notify(tabId, message, type) {
        if (tabId) sendMessageSafe("tabs", "sendMessage", [tabId, {greeting: "toast", message: message}]);
        sendMessageSafe("runtime", "sendMessage", [{greeting: "featureStatus", message: message, type: type || "info"}]);
    }

    function storageSyncGet(keys) {
        return new Promise((resolve, reject) => {
            chrome.storage.sync.get(keys, (value) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(value || {});
            });
        });
    }

    function aiEndpoint(baseUrl) {
        const endpoint = String(baseUrl || "").trim().replace(/\/$/, "");
        if (/\/(?:chat\/)?completions$/i.test(endpoint)) return endpoint;
        if (/\/chat$/i.test(endpoint)) return endpoint + "/completions";
        return endpoint + "/chat/completions";
    }

    async function aiRestore(code, sourceUrl) {
        const settings = await storageSyncGet(["AI"]);
        const config = settings.AI || {};
        const required = ["AIbaseURL", "AIapiKey", "AImodel", "AISystemPrompt", "AIUserPrompt"];
        if (required.some((key) => !config[key])) throw new Error("请先在配置页填写完整的 AI 参数");
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 90000);
        try {
            const template = String(config.AIUserPrompt);
            const hasCodePlaceholder = /\{\{code\}\}/i.test(template);
            const userPrompt = template
                .replace(/\{\{source\}\}|\{url\}/gi, sourceUrl || "")
                .replace(/\{\{code\}\}/gi, code) + (hasCodePlaceholder ? "" : "\n\n待分析代码：\n" + code);
            const response = await fetch(aiEndpoint(config.AIbaseURL), {
                method: "POST",
                headers: {"Content-Type": "application/json", "Authorization": "Bearer " + config.AIapiKey},
                body: JSON.stringify({
                    model: config.AImodel,
                    temperature: 0,
                    messages: [
                        {role: "system", content: config.AISystemPrompt},
                        {role: "user", content: userPrompt}
                    ],
                    stream: false
                }),
                signal: controller.signal
            });
            if (!response.ok) throw new Error("AI 请求失败: HTTP " + response.status);
            const data = await response.json();
            const choice = data && data.choices && data.choices[0];
            const content = choice && choice.message && choice.message.content !== undefined ? choice.message.content : choice && choice.text;
            if (!content) throw new Error("AI 响应中没有文本内容");
            return Array.isArray(content) ? content.map((part) => part.text || "").join("\n") : String(content);
        } finally {
            clearTimeout(timeout);
        }
    }

    function parseAiUrls(content, sourceUrl) {
        const urls = [];
        const add = (value) => {
            const url = normalizeResource(value, sourceUrl);
            if (url && !urls.includes(url)) urls.push(url);
        };
        const text = String(content || "");
        const absolutePattern = /https?:\/\/[^\s"'`<>()[\]{},]+?\.m?js(?:[?#][^\s"'`<>()[\]{},]*)?/gi;
        let match;
        while ((match = absolutePattern.exec(text)) !== null) add(match[0]);
        const relativePattern = /(?:^|[\s\[({,:])((?:\.{0,2}\/|\/)?[A-Za-z0-9_$./-]+\.m?js(?:[?#][^\s"'`<>()[\]{},]*)?)/gim;
        while ((match = relativePattern.exec(text)) !== null) add(match[1]);
        return urls;
    }

    async function scanExtraUrls(current, urls) {
        const item = featureState(current);
        if (!item) return {scanned: 0, skipped: 0, failed: 0};
        const candidates = Array.from(new Set(urls || [])).filter((url) => {
            if (!/^https?:\/\//i.test(url) || item.visited_urls.includes(url)) return false;
            item.visited_urls.push(url);
            return true;
        });
        let scanned = 0;
        let failed = 0;
        for (let i = 0; i < candidates.length; i += 6) {
            const batch = candidates.slice(i, i + 6);
            await Promise.all(batch.map(async (url) => {
                try {
                    const response = await fetch(url, {method: "GET", credentials: "include", cache: "no-store", headers: {Accept: "*/*"}});
                    if (!response.ok) throw new Error("HTTP " + response.status);
                    const text = await response.text();
                    const result = extract_info(text);
                    result.current = current;
                    persist_tmp_data(result, url, current, true);
                    recordDynamicCode(current, url, text);
                    scanned++;
                } catch (e) {
                    failed++;
                    console.warn("extra resource fetch failed:", url, e);
                }
            }));
            chrome.storage.local.set({["findsomething_result_" + current]: item});
            refresh_count();
        }
        return {scanned: scanned, skipped: candidates.length - scanned - failed, failed: failed};
    }

    async function restoreAndScan(current, code, sourceUrl, tabId) {
        const item = featureState(current);
        if (!item) throw new Error("当前页面没有扫描结果");
        notify(tabId, "开始 AI 还原动态 JS...", "info");
        const content = await aiRestore(String(code || "").slice(0, MAX_CODE_LENGTH), sourceUrl);
        item.ai[code] = content;
        chrome.storage.local.set({["findsomething_result_" + current]: item});
        if (/\b(?:error|fail)\b/i.test(content.trim().split(/\r?\n/).pop() || "")) throw new Error("AI 判断该函数无法还原 JS 路径");
        const urls = parseAiUrls(content, sourceUrl);
        if (!urls.length) throw new Error("AI 没有返回可用的 JS URL");
        const result = await scanExtraUrls(current, urls);
        notify(tabId, "AI 还原完成，新增扫描 " + result.scanned + " 个 JS", "success");
        return {urls: urls, scanned: result.scanned, failed: result.failed, content: content};
    }

    async function traceParameters(current, code, sourceUrl) {
        let source = code;
        if (/^https?:\/\//i.test(sourceUrl || "")) {
            try {
                const response = await fetch(sourceUrl, {credentials: "include", cache: "no-store"});
                if (response.ok) source = await response.text();
            } catch (e) {}
        }
        return traceFunctionParameters(code, source);
    }

    self.FindSomethingFeatures = {
        recordDynamicCode: recordDynamicCode,
        scanExtraUrls: scanExtraUrls,
        restoreAndScan: restoreAndScan,
        traceParameters: traceParameters,
        traceFunctionParameters: traceFunctionParameters,
        resourceCandidates: resourceCandidates,
        featureState: featureState
    };
})();
