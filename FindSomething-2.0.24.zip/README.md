# FindSomething

基于 GitHub 开源源码构建的浏览器被动式信息提取扩展。它从当前页面及其脚本资源中提取 IP、域名、路径、URL、JWT、敏感信息等结果。

## 本地增强版

本版本不包含会员、订阅或远程授权依赖，直接加载源码即可使用。除原有被动提取功能外，增加：

- Vue 2 / Vue 3 实例与路由探测；
- 手动加载异步路由组件，并收集加载后的 JS 资源；
- 基于依赖无关分析器识别 `script.src`、`setAttribute('src')`、`import()`、`require()`、webpack chunk 和动态 publicPath；
- 对对象映射、字符串拼接和静态变量进行本地路径推断，并支持变量追踪；
- 使用用户自行配置的 OpenAI 兼容 API 还原无法静态推断的动态 JS URL，并自动加入扫描队列；
- 结果导出为 JSON / TXT / CSV。

## Chrome / Chromium 加载

1. 打开 `chrome://extensions/`。
2. 开启“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本源码目录：`/Users/c1ear/Documents/ChatGPT/信息泄露`。

## AI 配置

打开扩展的“配置”页面，填写接口地址、API Key、模型和提示词。接口按 OpenAI Chat Completions 格式调用；接口地址可以填写到 `/v1`，扩展会自动追加 `/chat/completions`。

AI 只在用户点击“AI 还原并扫描”时发送选中的动态代码，默认不会上传页面内容。

## 上游项目

本项目基于 [momosecurity/FindSomething](https://github.com/momosecurity/FindSomething) 的 GPL-3.0 源码，并保留原许可证文件。
