(function () {
    "use strict";

    const resultKeys = ["secret", "hot_secret", "ip", "ip_port", "domain", "sfz", "mobile", "mail", "jwt", "algorithm", "path", "incomplete_path", "url", "static"];
    let currentTab = null;
    let currentResult = null;

    function getCurrentTab() {
        return new Promise((resolve) => chrome.tabs.query({active: true, lastFocusedWindow: true}, (tabs) => resolve(tabs && tabs[0])));
    }

    function getLocal(keys) {
        return new Promise((resolve, reject) => chrome.storage.local.get(keys, (value) => {
            if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
            else resolve(value || {});
        }));
    }

    function send(message) {
        return new Promise((resolve, reject) => chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
            else resolve(response);
        }));
    }

    function setStatus(text) {
        const node = document.getElementById("taskstatus");
        if (node) node.textContent = text;
    }

    function safeSource(value) {
        return /^(?:https?|file):/i.test(value || "") ? value : "";
    }

    function sourceList(value) {
        const values = Array.isArray(value) ? value : [value];
        return Array.from(new Set(values.map(safeSource).filter(Boolean)));
    }

    async function copyText(value) {
        try {
            await navigator.clipboard.writeText(value);
        } catch (e) {
            const input = document.createElement("textarea");
            input.value = value;
            document.body.appendChild(input);
            input.select();
            document.execCommand("copy");
            input.remove();
        }
    }

    function renderItems(key, values, source) {
        const container = document.getElementById(key);
        if (!container) return;
        container.textContent = "";
        container.classList.toggle("empty", !values || !values.length);
        if (!values || !values.length) {
            container.textContent = "🈚️";
            return;
        }
        values.forEach((value) => {
            const row = document.createElement("div");
            row.className = "item";
            const sourceUrls = sourceList(source && source[value]);
            const text = document.createElement("span");
            text.textContent = value;
            text.title = "右键复制";
            text.addEventListener("contextmenu", (event) => {
                event.preventDefault();
                copyText(value);
            });
            const actions = document.createElement("span");
            actions.className = "item-actions";
            const copyButton = document.createElement("button");
            copyButton.className = "item-action";
            copyButton.textContent = "复制";
            copyButton.title = "复制此条信息";
            copyButton.onclick = async () => {
                await copyText(value);
                copyButton.textContent = "已复制";
                setTimeout(() => { copyButton.textContent = "复制"; }, 900);
            };
            if (sourceUrls.length) {
                sourceUrls.forEach((sourceUrl, index) => {
                    const link = document.createElement("a");
                    link.className = "item-action source-link";
                    const label = /\.m?js(?:[?#]|$)/i.test(sourceUrl) ? "打开JS" : "打开来源";
                    link.textContent = sourceUrls.length > 1 ? label + " " + (index + 1) : label;
                    link.title = sourceUrl;
                    link.href = sourceUrl;
                    link.target = "_blank";
                    link.rel = "noopener noreferrer";
                    actions.appendChild(link);
                });
            } else {
                const noSource = document.createElement("span");
                noSource.className = "item-action";
                noSource.textContent = "无来源";
                actions.appendChild(noSource);
            }
            actions.prepend(copyButton);
            row.append(text, actions);
            container.appendChild(row);
        });
    }

    function renderDynamic(data) {
        const container = document.getElementById("showCode");
        if (!container) return;
        container.textContent = "";
        const codes = data && Array.isArray(data.showCode) ? data.showCode : [];
        if (!codes.length) {
            container.textContent = "暂无动态加载函数";
            container.classList.add("empty");
            return;
        }
        container.classList.remove("empty");
        codes.forEach((code) => {
            const box = document.createElement("div");
            box.className = "dynamic-item";
            const sourceUrl = safeSource(data.source && data.source[code]);
            const source = document.createElement("a");
            source.textContent = sourceUrl ? "< 来源" : "动态函数";
            source.title = sourceUrl;
            if (sourceUrl) {
                source.href = sourceUrl;
                source.target = "_blank";
            }
            const codeNode = document.createElement("code");
            codeNode.textContent = code;
            const actions = document.createElement("div");
            actions.className = "dynamic-actions";
            const aiButton = document.createElement("button");
            aiButton.textContent = "AI 还原并扫描";
            aiButton.onclick = async () => {
                aiButton.disabled = true;
                aiButton.textContent = "分析中...";
                try {
                    const response = await send({
                        greeting: "aiRestore",
                        current: currentTab.url,
                        code: code,
                        source: sourceUrl,
                        tabId: currentTab.id
                    });
                    if (!response || !response.success) throw new Error((response && response.error) || "AI 分析失败");
                    setStatus("AI 还原完成，结果已刷新");
                } catch (e) {
                    setStatus(e.message || "AI 分析失败");
                } finally {
                    aiButton.disabled = false;
                    aiButton.textContent = "AI 还原并扫描";
                }
            };
            const traceButton = document.createElement("button");
            traceButton.textContent = "变量追踪";
            traceButton.onclick = async () => {
                traceButton.disabled = true;
                traceButton.textContent = "追踪中...";
                try {
                    const response = await send({
                        greeting: "traceParams",
                        current: currentTab.url,
                        code: code,
                        source: sourceUrl,
                        tabId: currentTab.id
                    });
                    if (!response || !response.success) throw new Error((response && response.error) || "变量追踪失败");
                    setStatus("变量追踪完成");
                } catch (e) {
                    setStatus(e.message || "变量追踪失败");
                } finally {
                    traceButton.disabled = false;
                    traceButton.textContent = "变量追踪";
                }
            };
            actions.append(aiButton, traceButton);
            box.append(source, codeNode, actions);

            const resources = data.dynamicResources && data.dynamicResources[code];
            if (resources && resources.length) {
                const resourceNode = document.createElement("div");
                resourceNode.className = "dynamic-resources";
                resourceNode.textContent = "本地推断资源：\n" + resources.join("\n");
                box.appendChild(resourceNode);
            }
            const aiResult = data.ai && data.ai[code];
            if (aiResult) {
                const aiNode = document.createElement("pre");
                aiNode.className = "ai-result";
                aiNode.textContent = "AI 分析结果：\n" + aiResult;
                box.appendChild(aiNode);
            }
            const traceResult = data.trace && data.trace[code];
            if (traceResult) {
                const traceNode = document.createElement("pre");
                traceNode.className = "trace-result";
                traceNode.textContent = traceResult.success
                    ? "变量追踪结果：\n" + (traceResult.variables || []).map((item) => item.name + " = " + (item.value === null ? "null" : typeof item.value === "object" ? JSON.stringify(item.value) : item.value)).join("\n")
                    : "变量追踪失败：" + (traceResult.error || "未知错误");
                box.appendChild(traceNode);
            }
            container.appendChild(box);
        });
    }

    function renderResult(data) {
        currentResult = data || {};
        resultKeys.forEach((key) => renderItems(key, currentResult[key], sourceMapFor(key)));
        renderDynamic(currentResult);
        if (currentResult.donetasklist && currentResult.tasklist) {
            setStatus(currentResult.done === "done"
                ? "处理完成：" + currentResult.donetasklist.length + "/" + currentResult.tasklist.length
                : "处理中：" + currentResult.donetasklist.length + "/" + currentResult.tasklist.length);
        }
    }

    function sourceMapFor(key) {
        if (key === "hot_secret") {
            return currentResult && currentResult.hot_source || {};
        }
        return currentResult && currentResult.source || {};
    }

    function renderVue(version, routes, meta) {
        const panel = document.getElementById("vue-panel");
        const summary = document.getElementById("vue-summary");
        const list = document.getElementById("vue-routes");
        if (!panel || !summary || !list) return;
        if ((!version && (!routes || !routes.length)) || (meta && meta.foundVue === false && (!routes || !routes.length))) {
            panel.hidden = true;
            return;
        }
        panel.hidden = false;
        const loaded = meta && meta.loadedCount ? "，已触发加载 " + meta.loadedCount + " 个组件" : "";
        const skipped = meta && meta.skippedCount ? "，失败 " + meta.skippedCount : "";
        summary.textContent = "Vue " + (version || "unknown") + "，共 " + ((routes && routes.length) || 0) + " 条路由" + loaded + skipped;
        list.textContent = "";
        (routes || []).forEach((route) => {
            const row = document.createElement("div");
            row.className = "route";
            row.textContent = (route.fullUrl || route.fullPath || route.path || "/") + (route.name ? " (" + route.name + ")" : "");
            row.title = "右键复制，点击打开";
            row.onclick = () => {
                const url = route.fullUrl || route.fullPath || route.path;
                if (url) chrome.tabs.create({url: url});
            };
            row.oncontextmenu = (event) => {
                event.preventDefault();
                copyText(route.fullUrl || route.fullPath || route.path || "");
            };
            list.appendChild(row);
        });
    }

    async function refreshVue() {
        if (!currentTab || !currentTab.url) return;
        const values = await getLocal(["vue_version_" + currentTab.url, "vue_routes_" + currentTab.url, "vue_meta_" + currentTab.url]);
        renderVue(values["vue_version_" + currentTab.url], values["vue_routes_" + currentTab.url], values["vue_meta_" + currentTab.url]);
    }

    function download(name, content, type) {
        const url = URL.createObjectURL(new Blob([content], {type: type}));
        const link = document.createElement("a");
        link.href = url;
        link.download = name;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function exportResult(format) {
        if (!currentResult) return;
        if (format === "json") {
            download("findsomething-result.json", JSON.stringify(currentResult, null, 2), "application/json");
            return;
        }
        const lines = [];
        resultKeys.forEach((key) => {
            if (currentResult[key] && currentResult[key].length) {
                lines.push("[" + key + "]");
                lines.push.apply(lines, currentResult[key]);
                lines.push("");
            }
        });
        if (currentResult.showCode && currentResult.showCode.length) {
            lines.push("[dynamic-code]");
            lines.push.apply(lines, currentResult.showCode);
        }
        if (currentResult.ai && Object.keys(currentResult.ai).length) {
            lines.push("[ai-analysis]");
            Object.keys(currentResult.ai).forEach((code) => {
                lines.push("CODE: " + code);
                lines.push(currentResult.ai[code]);
            });
        }
        if (format === "csv") {
            const rows = [["类型", "内容", "来源", "AI分析"]];
            const csvValue = (value) => '"' + String(value || "").replace(/"/g, '""') + '"';
            resultKeys.forEach((key) => (currentResult[key] || []).forEach((value) => rows.push([key, value, sourceList(sourceMapFor(key)[value]).join("\n"), currentResult.ai && currentResult.ai[value] ? "yes" : "no"])));
            (currentResult.showCode || []).forEach((value) => rows.push(["dynamic-code", value, currentResult.source && currentResult.source[value], currentResult.ai && currentResult.ai[value] ? "yes" : "no"]));
            download("findsomething-result.csv", rows.map((row) => row.map(csvValue).join(",")).join("\n"), "text/csv;charset=utf-8");
            return;
        }
        download("findsomething-result.txt", lines.join("\n"), "text/plain");
    }

    function installCopyButtons() {
        resultKeys.forEach((key) => {
            const title = document.getElementById(key).previousElementSibling;
            if (!title || title.querySelector("button")) return;
            const button = document.createElement("button");
            button.textContent = "复制";
            button.onclick = () => copyText((currentResult && currentResult[key] || []).join("\n"));
            title.appendChild(button);
        });
        document.getElementById("copy-routes").onclick = async () => {
            const values = await getLocal(["vue_routes_" + currentTab.url]);
            await copyText((values["vue_routes_" + currentTab.url] || []).map((route) => route.fullUrl || route.fullPath || route.path).join("\n"));
        };
    }

    async function init() {
        currentTab = await getCurrentTab();
        if (!currentTab || !currentTab.url) {
            setStatus("无法获取当前标签页");
            return;
        }
        installCopyButtons();
        const values = await getLocal(["findsomething_result_" + currentTab.url]);
        renderResult(values["findsomething_result_" + currentTab.url]);
        await refreshVue();

        document.getElementById("vue-analyze-button").onclick = async () => {
            setStatus("正在分析 Vue 并加载路由组件...");
            try {
                const response = await send({greeting: "vueAnalyze", current: currentTab.url, tabId: currentTab.id});
                if (!response || !response.success) throw new Error((response && response.error) || "Vue 分析失败");
            } catch (e) {
                setStatus(e.message || "Vue 分析失败");
            }
        };
        document.getElementById("export-json").onclick = () => exportResult("json");
        document.getElementById("export-txt").onclick = () => exportResult("txt");
        document.getElementById("export-csv").onclick = () => exportResult("csv");

        chrome.runtime.onMessage.addListener((message) => {
            if (message.greeting === "featureStatus") setStatus(message.message);
        });
        chrome.storage.onChanged.addListener(async (changes) => {
            const resultKey = "findsomething_result_" + currentTab.url;
            if (changes[resultKey]) renderResult(changes[resultKey].newValue);
            if (changes["vue_routes_" + currentTab.url] || changes["vue_version_" + currentTab.url] || changes["vue_meta_" + currentTab.url]) await refreshVue();
        });
        setInterval(async () => {
            const next = await getLocal(["findsomething_result_" + currentTab.url]);
            if (next["findsomething_result_" + currentTab.url]) renderResult(next["findsomething_result_" + currentTab.url]);
        }, 1000);
    }

    document.addEventListener("DOMContentLoaded", init);
})();
